package com.novelfull.reader

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

private const val HOME_URL = "https://novelfull.net/"

class MainActivity : ComponentActivity() {
    private var webView: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                NovelFullWebView(
                    startUrl = HOME_URL,
                    onCreated = { webView = it }
                )
            }
        }
    }

    @Deprecated("Use BackHandler in Compose")
    override fun onBackPressed() {
        val view = webView
        if (view?.canGoBack() == true) view.goBack() else super.onBackPressed()
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun NovelFullWebView(
    startUrl: String,
    onCreated: (WebView) -> Unit
) {
    var viewRef by remember { mutableStateOf<WebView?>(null) }

    BackHandler(enabled = viewRef?.canGoBack() == true) {
        viewRef?.goBack()
    }

    AndroidView(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.loadsImagesAutomatically = true
                settings.builtInZoomControls = false
                settings.displayZoomControls = false
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = false

                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        view: WebView,
                        request: WebResourceRequest
                    ): Boolean {
                        // Keep NovelFull navigation inside the app.
                        return false
                    }
                }

                onCreated(this)
                viewRef = this
                loadUrl(startUrl)
            }
        },
        onRelease = {
            viewRef = null
            it.stopLoading()
            it.destroy()
        }
    )
}
