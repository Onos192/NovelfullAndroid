package com.novelfull.reader

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.File

class OfflineReaderActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val file = File(intent.getStringExtra("file") ?: return)
        val raw = file.readText(Charsets.UTF_8)
        val title = raw.substringAfter("<!--TITLE:").substringBefore("-->")
        val html = raw.substringAfter("-->\n", "")
        val web = WebView(this)
        web.settings.javaScriptEnabled = false
        web.webViewClient = WebViewClient()
        web.loadDataWithBaseURL("https://novelfull.net/", "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head><body><h2>$title</h2>$html</body></html>", "text/html", "UTF-8", null)
        setContentView(web)
    }
    companion object {
        fun open(context: Context, file: File) {
            context.startActivity(Intent(context, OfflineReaderActivity::class.java).putExtra("file", file.absolutePath))
        }
    }
}
