package com.novelfull.reader

import android.content.Context
import androidx.work.*
import org.jsoup.Jsoup
import java.util.concurrent.TimeUnit

class DownloadWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val base = inputData.getString("base") ?: return Result.failure()
        val from = inputData.getInt("from", -1)
        val to = inputData.getInt("to", -1)
        if (from < 0 || to < from) return Result.failure()
        return try {
            for (n in from..to) {
                val url = NovelUtils.chapterUrl(base, n)
                val doc = Jsoup.connect(url).userAgent("Mozilla/5.0 (Android) NovelFullReader").timeout(20000).get()
                val content = doc.selectFirst("#chapter-content, .chapter-content, .reading-content, .content") ?: doc.body()
                val title = doc.title().ifBlank { "Chapter $n" }
                OfflineStore.save(applicationContext, n, title, content.outerHtml())
                setProgress(workDataOf("done" to (n - from + 1), "total" to (to - from + 1), "chapter" to n))
            }
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }

    companion object {
        fun enqueue(context: Context, currentUrl: String, from: Int, to: Int, wifiOnly: Boolean) {
            val base = NovelUtils.novelBaseUrl(currentUrl) ?: return
            val constraints = Constraints.Builder().setRequiredNetworkType(if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED).build()
            val request = OneTimeWorkRequestBuilder<DownloadWorker>()
                .setInputData(workDataOf("base" to base, "from" to from, "to" to to))
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build()
            WorkManager.getInstance(context).enqueue(request)
        }
    }
}
