package com.novelfull.reader

import android.content.Context
import java.io.File

object OfflineStore {
    data class Item(val title: String, val file: File)
    private fun dir(context: Context) = File(context.filesDir, "offline").apply { mkdirs() }
    fun save(context: Context, chapter: Int, title: String, html: String) {
        File(dir(context), "chapter-$chapter.html").writeText("<!--TITLE:$title-->\n$html", Charsets.UTF_8)
    }
    fun list(context: Context): List<Item> = dir(context).listFiles()
        ?.filter { it.extension == "html" }
        ?.sortedBy { it.name.removePrefix("chapter-").removeSuffix(".html").toIntOrNull() ?: 0 }
        ?.map { f -> Item(f.readLines().firstOrNull()?.removePrefix("<!--TITLE:")?.removeSuffix("-->") ?: f.name, f) }
        ?: emptyList()
}
