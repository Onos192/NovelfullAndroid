# NovelFull Reader v0.6

Improvements in v0.6:
- Reading Library for saved novels.
- Search novels from the app, then add the opened novel with **Library +**.
- Chapter-range downloads are started from the Library.
- Downloader resolves the actual NovelFull chapter links from the novel's paginated chapter list instead of guessing chapter URLs.
- Offline chapters are stored per novel and chapter.
- Online reading settings: font size, line spacing, margins, brightness and dark mode.
- Offline reading settings: font size, line spacing, margins, brightness and dark mode.
- More persistent hiding of known advertising frames/elements in the WebView.
- Followed novels can continue to be checked for new chapters.

The app remains a WebView-based reader for https://novelfull.net/.
