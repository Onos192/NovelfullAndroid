package com.novelfull.reader

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.WorkManager
import java.util.Locale

private const val HOME_URL = "https://novelfull.net/"
const val PREFS = "novelfull_prefs"
const val CHANNEL_ID = "novelfull_updates"

private data class ReaderSettings(
    val fontSize: Float,
    val lineHeight: Float,
    val margin: Float,
    val darkMode: Boolean,
    val brightness: Float
)

class MainActivity : ComponentActivity() {
    private var webView: WebView? = null
    private var currentUrl by mutableStateOf(HOME_URL)
    private var currentTitle by mutableStateOf("NovelFull")
    private var readerSettingsVersion by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        requestNotificationsIfNeeded()
        scheduleUpdateChecks(this)
        setContent {
            MaterialTheme {
                NovelFullApp(
                    startUrl = HOME_URL,
                    currentUrl = currentUrl,
                    currentTitle = currentTitle,
                    settingsVersion = readerSettingsVersion,
                    onUrlChanged = { currentUrl = it },
                    onTitleChanged = { currentTitle = it },
                    onNavigate = { url -> webView?.loadUrl(url) },
                    onCreated = { webView = it },
                    onSettingsChanged = { readerSettingsVersion++ },
                    onBrightnessChanged = { value ->
                        window.attributes = window.attributes.apply { screenBrightness = value }
                    }
                )
            }
        }
    }

    private fun requestNotificationsIfNeeded() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    private fun createNotificationChannel() {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Novel updates", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    @Deprecated("Use BackHandler in Compose")
    override fun onBackPressed() {
        val view = webView
        if (view?.canGoBack() == true) view.goBack() else super.onBackPressed()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NovelFullApp(
    startUrl: String,
    currentUrl: String,
    currentTitle: String,
    settingsVersion: Int,
    onUrlChanged: (String) -> Unit,
    onTitleChanged: (String) -> Unit,
    onNavigate: (String) -> Unit,
    onCreated: (WebView) -> Unit,
    onSettingsChanged: () -> Unit,
    onBrightnessChanged: (Float) -> Unit
) {
    val context = LocalContext.current
    var screen by remember { mutableStateOf("web") }
    var showSearch by remember { mutableStateOf(false) }
    var showFollow by remember { mutableStateOf(false) }
    var showOnlineSettings by remember { mutableStateOf(false) }
    var showDownload by remember { mutableStateOf(false) }
    var selectedBook by remember { mutableStateOf<LibraryStore.Book?>(null) }
    var refreshKey by remember { mutableIntStateOf(0) }
    var libraryRefresh by remember { mutableIntStateOf(0) }

    val isNovelPage = currentUrl.startsWith("https://novelfull.net/") && !currentUrl.contains("/search") && currentUrl != HOME_URL

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("NovelFull Reader") },
                actions = {
                    TextButton(onClick = { showSearch = true }) { Text("Search") }
                    TextButton(onClick = { screen = if (screen == "library") "web" else "library"; libraryRefresh++ }) { Text("Library") }
                    var menuOpen by remember { mutableStateOf(false) }
                    Box {
                        TextButton(onClick = { menuOpen = true }) { Text("More") }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("Add current novel to Library") },
                                enabled = isNovelPage,
                                onClick = {
                                    LibraryStore.add(context, currentTitle, currentUrl)
                                    libraryRefresh++
                                    menuOpen = false
                                }
                            )
                            DropdownMenuItem(text = { Text("Follow current novel") }, onClick = { showFollow = true; menuOpen = false })
                            DropdownMenuItem(text = { Text("Reading settings") }, onClick = { showOnlineSettings = true; menuOpen = false })
                        }
                    }
                }
            )
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            if (screen == "library") {
                LibraryScreen(
                    refreshKey = libraryRefresh,
                    onHome = { screen = "web"; refreshKey++; onNavigate(HOME_URL) },
                    onOpen = { url -> screen = "web"; refreshKey++; onNavigate(url) },
                    onDownload = { book -> showDownload = true; selectedBook = book },
                    onRemove = { book ->
                        OfflineStore.deleteNovel(context, book.url)
                        LibraryStore.remove(context, book.url)
                        libraryRefresh++
                    }
                )
            } else {
                NovelFullWebView(
                    startUrl = if (refreshKey == 0) startUrl else currentUrl,
                    currentUrl = currentUrl,
                    settingsVersion = settingsVersion,
                    onUrlChanged = onUrlChanged,
                    onTitleChanged = onTitleChanged,
                    onCreated = onCreated
                )
            }
        }
    }

    if (showSearch) {
        SearchDialog(
            onDismiss = { showSearch = false },
            onSearch = { url ->
                screen = "web"
                showSearch = false
                onNavigate(url)
            }
        )
    }

    if (showFollow) FollowDialog(currentUrl = currentUrl, onDismiss = { showFollow = false })
    if (showOnlineSettings) {
        OnlineSettingsDialog(
            onDismiss = { showOnlineSettings = false },
            onChanged = onSettingsChanged,
            onBrightnessChanged = onBrightnessChanged
        )
    }
    if (showDownload && selectedBook != null) {
        DownloadRangeDialog(book = selectedBook!!, onDismiss = { showDownload = false })
    }
}


@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun NovelFullWebView(
    startUrl: String,
    currentUrl: String,
    settingsVersion: Int,
    onUrlChanged: (String) -> Unit,
    onTitleChanged: (String) -> Unit,
    onCreated: (WebView) -> Unit
) {
    var viewRef by remember { mutableStateOf<WebView?>(null) }
    BackHandler(enabled = viewRef?.canGoBack() == true) { viewRef?.goBack() }

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.loadsImagesAutomatically = true
                settings.builtInZoomControls = false
                settings.displayZoomControls = false
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = false
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String) {
                        onUrlChanged(url)
                        onTitleChanged(view.title.orEmpty().ifBlank { "NovelFull" })
                        hideAds(view)
                        applyOnlineSettings(view)
                    }
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = false
                }
                onCreated(this)
                viewRef = this
                loadUrl(startUrl)
            }
        },
        update = {
            viewRef = it
            if (settingsVersion >= 0) applyOnlineSettings(it)
        },
        onRelease = { viewRef = null; it.stopLoading(); it.destroy() }
    )
}

private fun hideAds(webView: WebView) {
    val js = """
        (function(){
          function hide(){
            const selectors = [
              'iframe[src*="a-ads.com"]',
              'iframe[src*="doubleclick"]',
              'iframe[src*="googlesyndication"]',
              '.adsbygoogle','.ad-container','.advertisement','.ads','.adbox',
              'button[aria-label*="setting" i]',
              '[title*="setting" i]',
              '.setting','.settings','#setting','#settings'
            ];
            selectors.forEach(function(s){document.querySelectorAll(s).forEach(function(e){
              e.style.setProperty('display','none','important');
              e.style.setProperty('visibility','hidden','important');
              e.style.setProperty('height','0','important');
              e.style.setProperty('min-height','0','important');
              e.style.setProperty('margin','0','important');
              e.style.setProperty('padding','0','important');
            });});
            // Hide NovelFull's webpage reading-settings gear. The app has its own settings.
            document.querySelectorAll('i,svg').forEach(function(icon){
              var cls=(icon.getAttribute('class')||'').toLowerCase();
              var label=((icon.getAttribute('aria-label')||'')+' '+(icon.getAttribute('title')||'')).toLowerCase();
              if(cls.indexOf('cog')>=0 || cls.indexOf('gear')>=0 || label.indexOf('setting')>=0){
                var target=icon.closest('button,a,[role="button"]') || icon;
                target.style.setProperty('display','none','important');
              }
            });
            document.querySelectorAll('body *').forEach(function(e){
              var t=(e.innerText||'').trim();
              if(t==='Advertise In This Ad Space' || t==='Get started'){
                var q=e;
                for(var i=0;i<5 && q.parentElement;i++) q=q.parentElement;
                q.style.setProperty('display','none','important');
              }
            });
          }
          hide();
          if(window.__novelfullAdObserver) window.__novelfullAdObserver.disconnect();
          window.__novelfullAdObserver=new MutationObserver(hide);
          window.__novelfullAdObserver.observe(document.documentElement,{childList:true,subtree:true});
          setTimeout(hide,500); setTimeout(hide,1500); setTimeout(hide,3000);
        })();
    """.trimIndent()
    webView.evaluateJavascript(js, null)
}

private fun applyOnlineSettings(webView: WebView) {
    val context = webView.context
    val prefs = context.getSharedPreferences("online_reader_settings", Context.MODE_PRIVATE)
    val font = prefs.getFloat("font_size", 20f)
    val line = prefs.getFloat("line_height", 1.6f)
    val margin = prefs.getFloat("margin", 16f)
    val dark = prefs.getBoolean("dark_mode", false)
    val bg = if (dark) "#121212" else "#FFFFFF"
    val fg = if (dark) "#EEEEEE" else "#202020"
    val js = """
        (function(){
          var bg='$bg', fg='$fg';
          document.documentElement.style.setProperty('background-color',bg,'important');
          document.body.style.setProperty('background-color',bg,'important');
          document.body.style.setProperty('color',fg,'important');
          var style=document.getElementById('novelfullOnlineStyle'); if(style) style.remove();
          style=document.createElement('style'); style.id='novelfullOnlineStyle';
          style.textContent=`body,body *{box-sizing:border-box!important;} body{background:${bg}!important;color:${fg}!important;}
            #chapter-content,.chapter-content,.reading-content,.content{font-size:${font.toInt()}px!important;line-height:${String.format(Locale.US,"%.2f",line)}!important;padding-left:${margin.toInt()}px!important;padding-right:${margin.toInt()}px!important;}
            #chapter-content p,.chapter-content p,.reading-content p,.content p{font-size:inherit!important;line-height:inherit!important;}`;
          document.head.appendChild(style);
        })();
    """.trimIndent()
    webView.evaluateJavascript(js, null)
}

@Composable
private fun SearchDialog(onDismiss: () -> Unit, onSearch: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Search NovelFull") },
        text = { OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Novel title") }, singleLine = true) },
        confirmButton = {
            Button(enabled = query.isNotBlank(), onClick = { onSearch("https://novelfull.net/search?keyword=${Uri.encode(query.trim())}") }) { Text("Search") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun OnlineSettingsDialog(onDismiss: () -> Unit, onChanged: () -> Unit, onBrightnessChanged: (Float) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("online_reader_settings", Context.MODE_PRIVATE) }
    var font by remember { mutableStateOf(prefs.getFloat("font_size", 20f)) }
    var line by remember { mutableStateOf(prefs.getFloat("line_height", 1.6f)) }
    var margin by remember { mutableStateOf(prefs.getFloat("margin", 16f)) }
    var brightness by remember { mutableStateOf(prefs.getFloat("brightness", 1f)) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark_mode", false)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Reading settings") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 430.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text("Font size: ${font.toInt()} sp")
                Slider(font, { font = it }, valueRange = 14f..34f, modifier = Modifier.height(38.dp))
                Text("Line spacing: ${String.format(Locale.US, "%.1f", line)}")
                Slider(line, { line = it }, valueRange = 1f..2.2f, modifier = Modifier.height(38.dp))
                Text("Side margins: ${margin.toInt()} dp")
                Slider(margin, { margin = it }, valueRange = 4f..48f, modifier = Modifier.height(38.dp))
                Text("Brightness: ${(brightness * 100).toInt()}%")
                Slider(brightness, { brightness = it; onBrightnessChanged(it) }, valueRange = 0.2f..1f, modifier = Modifier.height(38.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Dark mode", Modifier.weight(1f))
                    Switch(checked = dark, onCheckedChange = { dark = it })
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                prefs.edit()
                    .putFloat("font_size", font)
                    .putFloat("line_height", line)
                    .putFloat("margin", margin)
                    .putFloat("brightness", brightness)
                    .putBoolean("dark_mode", dark)
                    .apply()
                onChanged()
                onDismiss()
            }) { Text("Save settings") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun DownloadRangeDialog(book: LibraryStore.Book, onDismiss: () -> Unit) {
    var from by remember { mutableStateOf("") }
    var to by remember { mutableStateOf("") }
    var wifiOnly by remember { mutableStateOf(true) }
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Download chapters") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(book.title)
                Text("Choose a range, for example 501 to 520.")
                OutlinedTextField(from, { from = it.filter(Char::isDigit) }, label = { Text("First chapter") })
                OutlinedTextField(to, { to = it.filter(Char::isDigit) }, label = { Text("Last chapter") })
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Wi-Fi only", Modifier.weight(1f)); Switch(wifiOnly, { wifiOnly = it })
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val a = from.toIntOrNull(); val b = to.toIntOrNull()
                if (a != null && b != null && b >= a) {
                    DownloadWorker.enqueue(context, book.title, book.url, a, b, wifiOnly)
                    onDismiss()
                }
            }) { Text("Start download") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun LibraryScreen(
    refreshKey: Int,
    onHome: () -> Unit,
    onOpen: (String) -> Unit,
    onDownload: (LibraryStore.Book) -> Unit,
    onRemove: (LibraryStore.Book) -> Unit
) {
    val context = LocalContext.current
    var books by remember(refreshKey) { mutableStateOf(LibraryStore.list(context)) }
    val allOffline = remember(refreshKey) { OfflineStore.list(context) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Reading Library", style = MaterialTheme.typography.headlineSmall)
                Text("Save novels here, then download chapter ranges for offline reading.", style = MaterialTheme.typography.bodyMedium)
            }
            TextButton(onClick = onHome) { Text("Online Home") }
        }
        Spacer(Modifier.height(12.dp))
        if (books.isEmpty()) {
            Text("Your library is empty. Use Search to find a novel, open its novel page, then tap More → Add current novel to Library.")
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(books, key = { it.url }) { book ->
                val count = allOffline.count { it.novelUrl == book.url }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(book.title, style = MaterialTheme.typography.titleMedium)
                        Text(if (count == 0) "No chapters downloaded" else "$count chapters available offline")
                        var expanded by remember(book.url) { mutableStateOf(false) }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { onOpen(book.url) }) { Text("Open") }
                            TextButton(onClick = { onDownload(book) }) { Text("Download") }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (count > 0) {
                                TextButton(onClick = { expanded = !expanded }) {
                                    Text(if (expanded) "Hide chapters" else "Offline chapters")
                                }
                            }
                            Spacer(Modifier.weight(1f))
                            TextButton(onClick = { onRemove(book); books = LibraryStore.list(context) }) { Text("Remove") }
                        }
                        if (expanded) {
                            val chapters = allOffline.filter { it.novelUrl == book.url }.sortedBy { it.chapter }
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                chapters.forEach { item ->
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        Text("Chapter ${item.chapter}", Modifier.weight(1f))
                                        TextButton(onClick = { OfflineReaderActivity.open(context, item.file) }) { Text("Read") }
                                        TextButton(onClick = { item.file.delete() }) { Text("Delete") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FollowDialog(currentUrl: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val novelUrl = NovelUtils.novelBaseUrl(currentUrl) ?: currentUrl.substringBefore("/chapter-").trimEnd('/').takeIf { it.startsWith("https://novelfull.net/") }
    val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    var followed by remember { mutableStateOf(novelUrl != null && prefs.getStringSet("followed", emptySet()).orEmpty().contains(novelUrl)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Follow this novel") },
        text = { Text(if (novelUrl != null && novelUrl != HOME_URL) "Follow this novel for update checks:\n$novelUrl" else "Open a novel first.") },
        confirmButton = {
            Button(enabled = novelUrl != null && novelUrl != HOME_URL, onClick = {
                val set = prefs.getStringSet("followed", emptySet()).orEmpty().toMutableSet()
                if (followed) set.remove(novelUrl) else set.add(novelUrl)
                prefs.edit().putStringSet("followed", set).apply()
                followed = !followed
                onDismiss()
            }) { Text(if (followed) "Unfollow" else "Follow") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
