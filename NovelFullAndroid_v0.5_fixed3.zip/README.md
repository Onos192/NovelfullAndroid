# NovelFull Reader v0.5

v0.5 improves the offline reading experience. Downloaded chapters now have an in-reader settings panel for font size, line spacing, side margins, screen brightness, and dark mode. Settings are remembered for future offline chapters.

The project can be built with the existing GitHub Actions workflow using Java 17 and Gradle 8.9.
