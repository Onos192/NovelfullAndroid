package com.novelfull.reader

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

private const val HOME_URL = "https://novelfull.net/"
const val PREFS = "novelfull_prefs"
const val CHANNEL_ID = "novelfull_updates"

class MainActivity : ComponentActivity() {
    private var webView: WebView? = null
    private var currentUrl by mutableStateOf(HOME_URL)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        requestNotificationsIfNeeded()
        scheduleUpdateChecks(this)
        setContent {
            MaterialTheme {
                NovelFullApp(
                    startUrl = HOME_URL,
                    currentUrl = currentUrl,
                    onUrlChanged = { currentUrl = it },
                    onNavigate = { url -> webView?.loadUrl(url) },
                    onCreated = { webView = it }
                )
            }
        }
    }

    private fun requestNotificationsIfNeeded() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    private fun createNotificationChannel() {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Novel updates", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    @Deprecated("Use BackHandler in Compose")
    override fun onBackPressed() {
        val view = webView
        if (view?.canGoBack() == true) view.goBack() else super.onBackPressed()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NovelFullApp(
    startUrl: String,
    currentUrl: String,
    onUrlChanged: (String) -> Unit,
    onNavigate: (String) -> Unit,
    onCreated: (WebView) -> Unit
) {
    var screen by remember { mutableStateOf("web") }
    var showDownload by remember { mutableStateOf(false) }
    var showFollow by remember { mutableStateOf(false) }
    var showSearch by remember { mutableStateOf(false) }
    var refreshKey by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("NovelFull Reader") },
                actions = {
                    TextButton(onClick = { showSearch = true }) { Text("Search") }
                    TextButton(onClick = { screen = if (screen == "downloads") "web" else "downloads" }) { Text("Downloads") }
                    TextButton(onClick = { showDownload = true }) { Text("Download") }
                    TextButton(onClick = { showFollow = true }) { Text("Follow") }
                }
            )
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            if (screen == "downloads") {
                OfflineLibrary(onOpen = { url -> screen = "web"; refreshKey++ })
            } else {
                NovelFullWebView(
                    startUrl = if (refreshKey == 0) startUrl else currentUrl,
                    currentUrl = currentUrl,
                    onUrlChanged = onUrlChanged,
                    onNavigate = onNavigate,
                    onCreated = onCreated
                )
            }
        }
    }

    if (showSearch) {
        SearchDialog(onDismiss = { showSearch = false }, onSearch = { url ->
            screen = "web"
            showSearch = false
            onNavigate(url)
        })
    }

    if (showDownload) {
        DownloadRangeDialog(currentUrl = currentUrl, onDismiss = { showDownload = false })
    }
    if (showFollow) {
        FollowDialog(currentUrl = currentUrl, onDismiss = { showFollow = false })
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun NovelFullWebView(
    startUrl: String,
    currentUrl: String,
    onUrlChanged: (String) -> Unit,
    onNavigate: (String) -> Unit,
    onCreated: (WebView) -> Unit
) {
    var viewRef by remember { mutableStateOf<WebView?>(null) }
    BackHandler(enabled = viewRef?.canGoBack() == true) { viewRef?.goBack() }

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.loadsImagesAutomatically = true
                settings.builtInZoomControls = false
                settings.displayZoomControls = false
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = false
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String) {
                        onUrlChanged(url)
                        hideAds(view)
                    }
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = false
                }
                onCreated(this)
                viewRef = this
                loadUrl(startUrl)
            }
        },
        update = { if (it.url != startUrl && currentUrl.isNotBlank() && currentUrl != it.url && startUrl == currentUrl) it.loadUrl(startUrl) },
        onRelease = { viewRef = null; it.stopLoading(); it.destroy() }
    )
}

private fun hideAds(webView: WebView) {
    val js = """
        (function(){
          const selectors = [
            '[id*=ad]:not(html):not(body):not([id*=head])',
            '[class*=ad]:not(html):not(body)',
            '.adsbygoogle','.ad-container','.advertisement','.ads','.adbox',
            'iframe[src*="doubleclick"]','iframe[src*="googlesyndication"]'
          ];
          selectors.forEach(function(s){ document.querySelectorAll(s).forEach(function(e){
            if ((e.innerText||'').length < 3000) e.style.setProperty('display','none','important');
          }); });
        })();
    """.trimIndent()
    webView.evaluateJavascript(js, null)
}

@Composable
private fun SearchDialog(onDismiss: () -> Unit, onSearch: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Search NovelFull") },
        text = {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Novel title") },
                singleLine = true
            )
        },
        confirmButton = {
            Button(
                enabled = query.isNotBlank(),
                onClick = {
                    val url = "https://novelfull.net/search?keyword=${Uri.encode(query.trim())}"
                    onSearch(url)
                }
            ) { Text("Search") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun DownloadRangeDialog(currentUrl: String, onDismiss: () -> Unit) {
    var from by remember { mutableStateOf("") }
    var to by remember { mutableStateOf("") }
    var wifiOnly by remember { mutableStateOf(true) }
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Download chapters") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Enter a chapter range. Example: 501 to 520")
                OutlinedTextField(from, { from = it.filter(Char::isDigit) }, label = { Text("First chapter") })
                OutlinedTextField(to, { to = it.filter(Char::isDigit) }, label = { Text("Last chapter") })
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Wi-Fi only")
                    Switch(wifiOnly, { wifiOnly = it })
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val a = from.toIntOrNull(); val b = to.toIntOrNull()
                if (a != null && b != null && b >= a && currentUrl.contains("novelfull.net")) {
                    DownloadWorker.enqueue(context, currentUrl, a, b, wifiOnly)
                    onDismiss()
                }
            }) { Text("Start download") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun FollowDialog(currentUrl: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val novelUrl = NovelUtils.novelBaseUrl(currentUrl)
    val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    var followed by remember { mutableStateOf(prefs.getStringSet("followed", emptySet())?.contains(novelUrl) == true) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Follow this novel") },
        text = { Text(if (novelUrl != null) "Follow the novel at:\n$novelUrl\n\nThe app can check periodically for new chapters." else "Open a novel or chapter first.") },
        confirmButton = {
            Button(enabled = novelUrl != null, onClick = {
                val set = prefs.getStringSet("followed", emptySet())?.toMutableSet() ?: mutableSetOf()
                if (followed) set.remove(novelUrl) else set.add(novelUrl)
                prefs.edit().putStringSet("followed", set).apply()
                followed = !followed
                onDismiss()
            }) { Text(if (followed) "Unfollow" else "Follow") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun OfflineLibrary(onOpen: (String) -> Unit) {
    val context = LocalContext.current
    var items by remember { mutableStateOf(OfflineStore.list(context)) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Offline chapters", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        if (items.isEmpty()) Text("No downloaded chapters yet. Use Download to save a range for offline reading.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(items) { item ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(item.title, style = MaterialTheme.typography.titleMedium)
                        Text(item.file.name)
                        Row {
                            TextButton(onClick = { OfflineReaderActivity.open(context, item.file) }) { Text("Read") }
                            TextButton(onClick = { item.file.delete(); items = OfflineStore.list(context) }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
}
