package com.novelfull.reader

object NovelUtils {
    private val chapterRegex = Regex("/chapter-(\\d+)(?:-[^/?#]+)?\\.html", RegexOption.IGNORE_CASE)
    fun chapterNumber(url: String): Int? = chapterRegex.find(url)?.groupValues?.getOrNull(1)?.toIntOrNull()
    fun novelBaseUrl(url: String): String? {
        val m = chapterRegex.find(url) ?: return null
        return url.substring(0, m.range.first).trimEnd('/')
    }
    fun chapterUrl(base: String, number: Int): String = "$base/chapter-$number.html"
}
