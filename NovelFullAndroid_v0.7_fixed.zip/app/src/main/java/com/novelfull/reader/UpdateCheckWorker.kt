package com.novelfull.reader

import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import org.jsoup.Jsoup

class UpdateCheckWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val followed = prefs.getStringSet("followed", emptySet()) ?: emptySet()
        followed.forEach { url ->
            try {
                val doc = Jsoup.connect(url).userAgent("Mozilla/5.0 (Android) NovelFullReader").timeout(15000).get()
                val nums = doc.select("a[href*='/chapter-']").mapNotNull { NovelUtils.chapterNumber(it.absUrl("href")) }
                val latest = nums.maxOrNull() ?: return@forEach
                val key = "latest:$url"
                val old = prefs.getInt(key, -1)
                if (old >= 0 && latest > old) {
                    val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    nm.notify(url.hashCode(), NotificationCompat.Builder(applicationContext, CHANNEL_ID)
                        .setSmallIcon(android.R.drawable.ic_dialog_info)
                        .setContentTitle("New NovelFull chapter")
                        .setContentText("Chapter $latest is available")
                        .setAutoCancel(true).build())
                }
                prefs.edit().putInt(key, latest).apply()
            } catch (_: Exception) { }
        }
        return Result.success()
    }
}

fun scheduleUpdateChecks(context: Context) {
    val constraints = androidx.work.Constraints.Builder().setRequiredNetworkType(androidx.work.NetworkType.CONNECTED).build()
    val request = androidx.work.PeriodicWorkRequestBuilder<UpdateCheckWorker>(6, java.util.concurrent.TimeUnit.HOURS)
        .setConstraints(constraints).build()
    androidx.work.WorkManager.getInstance(context).enqueueUniquePeriodicWork("novelfull-update-check", androidx.work.ExistingPeriodicWorkPolicy.KEEP, request)
}
