package com.novelfull.reader

import android.content.Context
import android.os.Bundle
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import java.io.File
import kotlin.math.roundToInt

class OfflineReaderActivity : ComponentActivity() {
    private var originalBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        originalBrightness = window.attributes.screenBrightness
        val file = File(intent.getStringExtra("file") ?: run { finish(); return })
        val raw = file.readText(Charsets.UTF_8)
        val parts = raw.split("\n---NOVELFULL-FIELD---\n", limit = 5)
        val novelTitle = if (parts.size >= 5) parts[0] else ""
        val novelUrl = if (parts.size >= 5) parts[1] else ""
        val chapter = if (parts.size >= 5) parts[2].toIntOrNull() ?: 0 else 0
        val title = if (parts.size >= 5) parts[3] else raw.substringAfter("<!--TITLE:").substringBefore("-->")
        val html = if (parts.size >= 5) parts[4] else raw.substringAfter("-->\n", "")

        setContent {
            MaterialTheme {
                OfflineReaderScreen(
                    title = title,
                    novelTitle = novelTitle,
                    novelUrl = novelUrl,
                    chapter = chapter,
                    html = html,
                    onBrightnessChanged = { value ->
                        window.attributes = window.attributes.apply { screenBrightness = value }
                    },
                    onBack = { finish() }
                )
            }
        }
    }

    override fun onDestroy() {
        window.attributes = window.attributes.apply { screenBrightness = originalBrightness }
        super.onDestroy()
    }

    companion object {
        fun open(context: Context, file: File) {
            context.startActivity(android.content.Intent(context, OfflineReaderActivity::class.java).putExtra("file", file.absolutePath))
        }
    }
}

@Composable
private fun OfflineReaderScreen(
    title: String,
    novelTitle: String,
    novelUrl: String,
    chapter: Int,
    html: String,
    onBrightnessChanged: (Float) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("offline_reader_settings", Context.MODE_PRIVATE) }
    var fontSize by remember { mutableStateOf(prefs.getFloat("font_size", 20f)) }
    var lineHeight by remember { mutableStateOf(prefs.getFloat("line_height", 1.55f)) }
    var margin by remember { mutableStateOf(prefs.getFloat("margin", 18f)) }
    var brightness by remember { mutableStateOf(prefs.getFloat("brightness", 1f)) }
    var darkMode by remember { mutableStateOf(prefs.getBoolean("dark_mode", false)) }
    var showSettings by remember { mutableStateOf(false) }
    var webReady by remember { mutableStateOf(false) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    val downloadedChapters = remember(novelUrl, chapter) {
        OfflineStore.listForNovel(context, novelUrl).sortedBy { it.chapter }
    }
    val currentIndex = downloadedChapters.indexOfFirst { it.chapter == chapter }
    val previousItem = downloadedChapters.getOrNull(currentIndex - 1)
    val nextItem = downloadedChapters.getOrNull(currentIndex + 1)

    fun save() {
        prefs.edit()
            .putFloat("font_size", fontSize)
            .putFloat("line_height", lineHeight)
            .putFloat("margin", margin)
            .putFloat("brightness", brightness)
            .putBoolean("dark_mode", darkMode)
            .apply()
    }

    fun applyCss() {
        val bg = if (darkMode) "#121212" else "#FFFFFF"
        val fg = if (darkMode) "#EEEEEE" else "#202020"
        val link = if (darkMode) "#90CAF9" else "#1565C0"
        val js = """
            (function(){
              var old=document.getElementById('novelfullOfflineStyle'); if(old) old.remove();
              var s=document.createElement('style'); s.id='novelfullOfflineStyle';
              s.textContent=`html,body{background:${bg}!important;color:${fg}!important;}
                body{font-size:${fontSize.roundToInt()}px!important;line-height:${"%.2f".format(java.util.Locale.US, lineHeight)}!important;padding:12px ${margin.roundToInt()}px 40px ${margin.roundToInt()}px!important;max-width:100%!important;box-sizing:border-box!important;}
                body p,body div,body li{font-size:inherit!important;line-height:inherit!important;}
                a{color:${link}!important;}`;
              document.head.appendChild(s);
            })();
        """.trimIndent()
        webViewRef?.evaluateJavascript(js, null)
        save()
    }

    LaunchedEffect(Unit) { onBrightnessChanged(brightness) }
    LaunchedEffect(fontSize, lineHeight, margin, darkMode, webReady) { if (webReady) applyCss() }

    DisposableEffect(Unit) {
        onDispose { save() }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = false
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView, url: String) {
                            webReady = true
                        }
                    }
                    webViewRef = this
                    val bg = if (darkMode) "#121212" else "#FFFFFF"
                    val fg = if (darkMode) "#EEEEEE" else "#202020"
                    loadDataWithBaseURL(
                        "https://novelfull.net/",
                        """
                        <html><head><meta name='viewport' content='width=device-width, initial-scale=1.0'>
                        <style>
                          html,body{margin:0;background:$bg;color:$fg;font-family:sans-serif;}
                          img{max-width:100%;height:auto;}
                          *{box-sizing:border-box;}
                        </style></head><body><h2>${escapeHtml(title)}</h2>$html</body></html>
                        """.trimIndent(),
                        "text/html", "UTF-8", null
                    )
                }
            },
            update = { webViewRef = it }
        )

        Surface(
            modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().systemBarsPadding(),
            tonalElevation = 4.dp
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Text("‹", fontSize = 34.sp) }
                IconButton(
                    onClick = { previousItem?.let { OfflineReaderActivity.open(context, it.file) } },
                    enabled = previousItem != null
                ) { Text("‹", fontSize = 28.sp) }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Offline", style = MaterialTheme.typography.titleMedium)
                    if (chapter > 0) Text("Chapter $chapter", style = MaterialTheme.typography.labelMedium)
                }
                IconButton(
                    onClick = { nextItem?.let { OfflineReaderActivity.open(context, it.file) } },
                    enabled = nextItem != null
                ) { Text("›", fontSize = 28.sp) }
                IconButton(onClick = { showSettings = !showSettings }) { Text("⚙", fontSize = 24.sp) }
            }
        }

        if (showSettings) {
            Surface(
                modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter),
                tonalElevation = 8.dp,
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier.padding(16.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Reading settings", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                        Button(onClick = { showSettings = false }) { Text("Done") }
                    }
                    Text("Font size: ${fontSize.roundToInt()} sp")
                    Slider(value = fontSize, onValueChange = { fontSize = it }, valueRange = 14f..32f)
                    Text("Line spacing: ${"%.1f".format(java.util.Locale.US, lineHeight)}")
                    Slider(value = lineHeight, onValueChange = { lineHeight = it }, valueRange = 1.0f..2.2f)
                    Text("Side margins: ${margin.roundToInt()} dp")
                    Slider(value = margin, onValueChange = { margin = it }, valueRange = 4f..48f)
                    Text("Screen brightness: ${(brightness * 100).roundToInt()}%")
                    Slider(value = brightness, onValueChange = { brightness = it; onBrightnessChanged(it) }, valueRange = 0.2f..1f)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Dark mode", modifier = Modifier.weight(1f))
                        Switch(checked = darkMode, onCheckedChange = { darkMode = it })
                    }
                }
            }
        }
    }
}

private fun escapeHtml(value: String): String = value
    .replace("&", "&amp;")
    .replace("<", "&lt;")
    .replace(">", "&gt;")
    .replace("\"", "&quot;")
    .replace("'", "&#39;")
