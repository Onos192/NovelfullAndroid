package com.novelfull.reader

import android.content.Context
import android.util.Base64

object LibraryStore {
    data class Book(val title: String, val url: String)
    private const val PREFS = "novelfull_library"
    private const val KEY = "books"

    fun list(context: Context): List<Book> = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getStringSet(KEY, emptySet())
        .orEmpty()
        .mapNotNull { encoded ->
            runCatching {
                val raw = String(Base64.decode(encoded, Base64.NO_WRAP), Charsets.UTF_8)
                val i = raw.indexOf('|')
                if (i <= 0) null else Book(raw.substring(0, i), raw.substring(i + 1))
            }.getOrNull()
        }
        .sortedBy { it.title.lowercase() }

    fun add(context: Context, title: String, url: String) {
        val normalized = NovelUtils.novelBaseUrl(url) ?: url.substringBefore("/chapter-").trimEnd('/')
        if (!normalized.startsWith("https://novelfull.net/")) return
        val cleanedTitle = title.substringBefore(" - NovelFull").replace(Regex("\\s+Chapter\\s+\\d+.*$", RegexOption.IGNORE_CASE), "").trim()
        val fallback = normalized.substringAfterLast('/').replace('-', ' ').replaceFirstChar { it.uppercase() }
        val book = Book(cleanedTitle.ifBlank { fallback }, normalized)
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val set = prefs.getStringSet(KEY, emptySet()).orEmpty().toMutableSet()
        val encoded = Base64.encodeToString("${book.title}|${book.url}".toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        set.removeAll { decodeUrl(it) == book.url }
        set.add(encoded)
        prefs.edit().putStringSet(KEY, set).apply()
        val followPrefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val followed = followPrefs.getStringSet("followed", emptySet()).orEmpty().toMutableSet()
        followed.add(book.url)
        followPrefs.edit().putStringSet("followed", followed).apply()
    }

    fun remove(context: Context, url: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val set = prefs.getStringSet(KEY, emptySet()).orEmpty().filterTo(mutableSetOf()) { decodeUrl(it) != url }
        prefs.edit().putStringSet(KEY, set).apply()
    }

    private fun decodeUrl(encoded: String): String? = runCatching {
        val raw = String(Base64.decode(encoded, Base64.NO_WRAP), Charsets.UTF_8)
        raw.substringAfter('|', "")
    }.getOrNull()
}
