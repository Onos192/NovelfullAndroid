package com.novelfull.reader

import android.content.Context
import java.io.File
import java.security.MessageDigest

object OfflineStore {
    data class Item(
        val novelTitle: String,
        val novelUrl: String,
        val chapter: Int,
        val title: String,
        val file: File
    )

    private fun dir(context: Context) = File(context.filesDir, "offline").apply { mkdirs() }

    fun save(context: Context, novelTitle: String, novelUrl: String, chapter: Int, title: String, html: String) {
        val safeNovel = sha256(novelUrl).take(16)
        val file = File(dir(context), "$safeNovel-chapter-$chapter.html")
        val payload = listOf(novelTitle, novelUrl, chapter.toString(), title, html).joinToString("\n---NOVELFULL-FIELD---\n")
        file.writeText(payload, Charsets.UTF_8)
    }

    fun list(context: Context): List<Item> = dir(context).listFiles()
        ?.filter { it.extension == "html" }
        ?.mapNotNull { readItem(it) }
        ?.sortedWith(compareBy<Item> { it.novelTitle.lowercase() }.thenBy { it.chapter })
        ?: emptyList()

    fun listForNovel(context: Context, novelUrl: String): List<Item> = list(context).filter { it.novelUrl == novelUrl }

    fun deleteNovel(context: Context, novelUrl: String) {
        listForNovel(context, novelUrl).forEach { it.file.delete() }
    }

    private fun readItem(file: File): Item? = runCatching {
        val parts = file.readText(Charsets.UTF_8).split("\n---NOVELFULL-FIELD---\n", limit = 5)
        if (parts.size < 5) return null
        Item(parts[0], parts[1], parts[2].toInt(), parts[3], file)
    }.getOrNull()

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}
