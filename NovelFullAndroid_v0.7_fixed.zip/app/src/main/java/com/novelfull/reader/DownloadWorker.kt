package com.novelfull.reader

import android.content.Context
import androidx.work.*
import org.jsoup.Jsoup
import java.util.concurrent.TimeUnit

class DownloadWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val novelUrl = inputData.getString("novelUrl") ?: return Result.failure()
        val novelTitle = inputData.getString("novelTitle") ?: "Novel"
        val from = inputData.getInt("from", -1)
        val to = inputData.getInt("to", -1)
        if (from < 1 || to < from) return Result.failure()

        return try {
            val chapterUrls = resolveChapterUrls(novelUrl, from, to)
            if (chapterUrls.isEmpty()) return Result.failure(workDataOf("error" to "No chapter links were found for that range."))
            var done = 0
            for (number in from..to) {
                val url = chapterUrls[number] ?: continue
                val doc = Jsoup.connect(url).userAgent("Mozilla/5.0 (Android) NovelFullReader").timeout(20000).get()
                val content = doc.selectFirst("#chapter-content, .chapter-content, .reading-content, .content") ?: doc.body()
                val title = doc.selectFirst("h1")?.text()?.ifBlank { null } ?: doc.title().ifBlank { "Chapter $number" }
                OfflineStore.save(applicationContext, novelTitle, novelUrl, number, title, content.outerHtml())
                done++
                setProgress(workDataOf("done" to done, "total" to (to - from + 1), "chapter" to number))
            }
            if (done == 0) Result.failure(workDataOf("error" to "No chapters could be downloaded.")) else Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    private fun resolveChapterUrls(novelUrl: String, from: Int, to: Int): Map<Int, String> {
        val firstPage = ((from - 1) / PAGE_SIZE) + 1
        val lastPage = ((to - 1) / PAGE_SIZE) + 1
        val result = mutableMapOf<Int, String>()
        for (page in firstPage..lastPage) {
            val pageUrl = if (page == 1) novelUrl else if (novelUrl.contains("?")) "$novelUrl&page=$page" else "$novelUrl?page=$page"
            val doc = Jsoup.connect(pageUrl).userAgent("Mozilla/5.0 (Android) NovelFullReader").timeout(20000).get()
            doc.select("a[href]").forEach { a ->
                val href = a.absUrl("href")
                val number = NovelUtils.chapterNumber(href)
                if (number != null && number in from..to) result[number] = href
            }
        }
        return result
    }

    companion object {
        private const val PAGE_SIZE = 40

        fun enqueue(context: Context, novelTitle: String, novelUrl: String, from: Int, to: Int, wifiOnly: Boolean) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED)
                .build()
            val request = OneTimeWorkRequestBuilder<DownloadWorker>()
                .setInputData(workDataOf("novelTitle" to novelTitle, "novelUrl" to novelUrl, "from" to from, "to" to to))
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build()
            WorkManager.getInstance(context).enqueue(request)
        }
    }
}
