# NovelFull Reader — Android prototype

This is a first Android prototype that wraps the NovelFull website in an Android WebView.

## Requirements
- Android Studio
- Android SDK 35
- JDK 17
- Internet connection

## Run
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect an Android phone with USB debugging enabled, or start an emulator.
4. Press Run.

## Current features
- Opens https://novelfull.net/
- Keeps website navigation inside the app.
- Android back button navigates WebView history.
- JavaScript and DOM storage are enabled for compatibility.
- Edge-to-edge safe-area padding is applied.

## Next development stage
Possible additions:
- Native app toolbar
- Favourites/bookmarks
- Reading history
- Saved reading position
- Reader font controls
- Dark reading mode
- Offline storage where legally permitted
- Splash screen and custom icon
- App settings
- Error/offline screen

## Important
This prototype does not copy novels into the app. It displays the website remotely. Before publishing or redistributing website content, verify that the app's use complies with NovelFull's terms and applicable copyright/licensing requirements.
